
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "RC"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_RC
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/resources/app_icon.rc" "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/CMakeFiles/BatteryTool.dir/resources/app_icon.rc.obj"
  )

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_RC
  "MINGW_HAS_SECURE_API=1"
  "QT_CORE_LIB"
  "QT_GUI_LIB"
  "QT_NEEDS_QMAIN"
  "QT_NETWORK_LIB"
  "QT_NO_DEBUG"
  "QT_SERIALPORT_LIB"
  "QT_SVG_LIB"
  "QT_WIDGETS_LIB"
  "UNICODE"
  "WIN32"
  "WIN64"
  "_ENABLE_EXTENDED_ALIGNED_STORAGE"
  "_UNICODE"
  "_WIN64"
  )

# The include file search paths:
set(CMAKE_RC_TARGET_INCLUDE_PATH
  "BatteryTool_autogen/include"
  "C:/Qt/6.12.0/mingw_64/include/QtCore"
  "C:/Qt/6.12.0/mingw_64/include"
  "C:/Qt/6.12.0/mingw_64/mkspecs/win32-g++"
  "C:/Qt/6.12.0/mingw_64/include/QtWidgets"
  "C:/Qt/6.12.0/mingw_64/include/QtGui"
  "C:/Qt/6.12.0/mingw_64/include/QtSerialPort"
  "C:/Qt/6.12.0/mingw_64/include/QtNetwork"
  "C:/Qt/6.12.0/mingw_64/include/QtSvg"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "" "BatteryTool_autogen/timestamp" "custom" "BatteryTool_autogen/deps"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/BatteryTool_autogen/3YJK5W5UP7/qrc_resources.cpp" "CMakeFiles/BatteryTool.dir/BatteryTool_autogen/3YJK5W5UP7/qrc_resources.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/BatteryTool_autogen/3YJK5W5UP7/qrc_resources.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/BatteryTool_autogen/mocs_compilation.cpp" "CMakeFiles/BatteryTool.dir/BatteryTool_autogen/mocs_compilation.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/BatteryTool_autogen/mocs_compilation.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/branding.cpp" "CMakeFiles/BatteryTool.dir/src/branding.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/branding.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/gauges.cpp" "CMakeFiles/BatteryTool.dir/src/gauges.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/gauges.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/main.cpp" "CMakeFiles/BatteryTool.dir/src/main.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/main.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/main_window.cpp" "CMakeFiles/BatteryTool.dir/src/main_window.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/main_window.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/monitor_panel.cpp" "CMakeFiles/BatteryTool.dir/src/monitor_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/monitor_panel.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/plot_panel.cpp" "CMakeFiles/BatteryTool.dir/src/plot_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/plot_panel.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/plot_widgets.cpp" "CMakeFiles/BatteryTool.dir/src/plot_widgets.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/plot_widgets.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/protocol.cpp" "CMakeFiles/BatteryTool.dir/src/protocol.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/protocol.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/serial_link.cpp" "CMakeFiles/BatteryTool.dir/src/serial_link.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/serial_link.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/serial_settings_panel.cpp" "CMakeFiles/BatteryTool.dir/src/serial_settings_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/serial_settings_panel.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/settings_panel.cpp" "CMakeFiles/BatteryTool.dir/src/settings_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/settings_panel.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/simulate_panel.cpp" "CMakeFiles/BatteryTool.dir/src/simulate_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/simulate_panel.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/status_chips.cpp" "CMakeFiles/BatteryTool.dir/src/status_chips.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/status_chips.cpp.obj.d"
  "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/src/terminal_panel.cpp" "CMakeFiles/BatteryTool.dir/src/terminal_panel.cpp.obj" "gcc" "CMakeFiles/BatteryTool.dir/src/terminal_panel.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
