CMakeFiles/BatteryTool.dir/BatteryTool_autogen/3YJK5W5UP7/qrc_resources.cpp.obj: \
 C:\Users\russe\Repositories\MIL\SubjuGator9\Battery-ORing-Monitoring\V2\CODE\gui\build\Desktop_Qt_6_12_0_MinGW_64_bit_Release\BatteryTool_autogen\3YJK5W5UP7\qrc_resources.cpp
