# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for BatteryTool_autogen.
