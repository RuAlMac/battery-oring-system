file(REMOVE_RECURSE
  "BatteryTool_autogen/mocs_compilation.cpp"
  "BatteryTool_autogen/timestamp"
  "CMakeFiles/BatteryTool_autogen"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/BatteryTool_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
