include("C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/.qt/QtDeploySupport.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/BatteryTool-plugins.cmake" OPTIONAL)
set(__QT_DEPLOY_I18N_CATALOGS "qtbase;qtserialport")

qt6_deploy_runtime_dependencies(
    EXECUTABLE "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/BatteryTool.exe"
    GENERATE_QT_CONF
    NO_TRANSLATIONS
)
