set(__QT_DEPLOY_TARGETS "BatteryTool")
set(__QT_DEPLOY_TARGET_BatteryTool_FILE C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/BatteryTool.exe)
set(__QT_DEPLOY_TARGET_BatteryTool_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_BatteryTool_RUNTIME_DLLS C:/Qt/6.12.0/mingw_64/bin/Qt6Widgets.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6SerialPort.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Network.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Svg.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Gui.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Core.dll)
