# This file will be configured to contain variables for CPack. These variables
# should be set in the CMake list file of the project before CPack module is
# included. The list of available CPACK_xxx variables and their associated
# documentation may be obtained using
#  cpack --help-variable-list
#
# Some variables are common to all generators (e.g. CPACK_PACKAGE_NAME)
# and some are specific to a generator
# (e.g. CPACK_NSIS_EXTRA_INSTALL_COMMANDS). The generator specific variables
# usually begin with CPACK_<GENNAME>_xxxx.


set(CPACK_BUILD_SOURCE_DIRS "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui;C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release")
set(CPACK_CMAKE_GENERATOR "MinGW Makefiles")
set(CPACK_COMPONENT_UNSPECIFIED_HIDDEN "TRUE")
set(CPACK_COMPONENT_UNSPECIFIED_REQUIRED "TRUE")
set(CPACK_DEFAULT_PACKAGE_DESCRIPTION_FILE "C:/Qt/Tools/CMake_64/share/cmake-3.30/Templates/CPack.GenericDescription.txt")
set(CPACK_DEFAULT_PACKAGE_DESCRIPTION_SUMMARY "MIL_ORing_Monitoring_Config_Tool built using CMake")
set(CPACK_GENERATOR "ZIP")
set(CPACK_INCLUDE_TOPLEVEL_DIRECTORY "ON")
set(CPACK_INNOSETUP_ARCHITECTURE "x64")
set(CPACK_INSTALL_CMAKE_PROJECTS "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release;MIL_ORing_Monitoring_Config_Tool;ALL;/")
set(CPACK_INSTALL_PREFIX "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/dist/BatteryTool")
set(CPACK_MODULE_PATH "C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6;C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6/3rdparty/extra-cmake-modules/find-modules;C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6/3rdparty/kwin;C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6;C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6/3rdparty/extra-cmake-modules/find-modules;C:/Qt/6.12.0/mingw_64/lib/cmake/Qt6/3rdparty/kwin")
set(CPACK_NSIS_DISPLAY_NAME "BatteryTool 0.1")
set(CPACK_NSIS_INSTALLER_ICON_CODE "")
set(CPACK_NSIS_INSTALLER_MUI_ICON_CODE "")
set(CPACK_NSIS_INSTALL_ROOT "$PROGRAMFILES64")
set(CPACK_NSIS_PACKAGE_NAME "BatteryTool 0.1")
set(CPACK_NSIS_UNINSTALL_NAME "Uninstall")
set(CPACK_OBJCOPY_EXECUTABLE "C:/Qt/Tools/mingw1310_64/bin/objcopy.exe")
set(CPACK_OBJDUMP_EXECUTABLE "C:/Qt/Tools/mingw1310_64/bin/objdump.exe")
set(CPACK_OUTPUT_CONFIG_FILE "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/CPackConfig.cmake")
set(CPACK_PACKAGE_DEFAULT_LOCATION "/")
set(CPACK_PACKAGE_DESCRIPTION_FILE "C:/Qt/Tools/CMake_64/share/cmake-3.30/Templates/CPack.GenericDescription.txt")
set(CPACK_PACKAGE_DESCRIPTION_SUMMARY "Battery ORing & Monitoring V2 configuration and monitoring tool")
set(CPACK_PACKAGE_FILE_NAME "BatteryTool-0.1-Windows")
set(CPACK_PACKAGE_INSTALL_DIRECTORY "BatteryTool 0.1")
set(CPACK_PACKAGE_INSTALL_REGISTRY_KEY "BatteryTool 0.1")
set(CPACK_PACKAGE_NAME "BatteryTool")
set(CPACK_PACKAGE_RELOCATABLE "true")
set(CPACK_PACKAGE_VENDOR "MIL - SubjuGator 9")
set(CPACK_PACKAGE_VERSION "0.1")
set(CPACK_PACKAGE_VERSION_MAJOR "0")
set(CPACK_PACKAGE_VERSION_MINOR "1")
set(CPACK_READELF_EXECUTABLE "C:/Qt/Tools/mingw1310_64/bin/readelf.exe")
set(CPACK_RESOURCE_FILE_LICENSE "C:/Qt/Tools/CMake_64/share/cmake-3.30/Templates/CPack.GenericLicense.txt")
set(CPACK_RESOURCE_FILE_README "C:/Qt/Tools/CMake_64/share/cmake-3.30/Templates/CPack.GenericDescription.txt")
set(CPACK_RESOURCE_FILE_WELCOME "C:/Qt/Tools/CMake_64/share/cmake-3.30/Templates/CPack.GenericWelcome.txt")
set(CPACK_SET_DESTDIR "OFF")
set(CPACK_SOURCE_7Z "ON")
set(CPACK_SOURCE_GENERATOR "7Z;ZIP")
set(CPACK_SOURCE_OUTPUT_CONFIG_FILE "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/CPackSourceConfig.cmake")
set(CPACK_SOURCE_ZIP "ON")
set(CPACK_SYSTEM_NAME "win64")
set(CPACK_THREADS "1")
set(CPACK_TOPLEVEL_TAG "win64")
set(CPACK_WIX_SIZEOF_VOID_P "8")

if(NOT CPACK_PROPERTIES_FILE)
  set(CPACK_PROPERTIES_FILE "C:/Users/russe/Repositories/MIL/SubjuGator9/Battery-ORing-Monitoring/V2/CODE/gui/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/CPackProperties.cmake")
endif()

if(EXISTS ${CPACK_PROPERTIES_FILE})
  include(${CPACK_PROPERTIES_FILE})
endif()
